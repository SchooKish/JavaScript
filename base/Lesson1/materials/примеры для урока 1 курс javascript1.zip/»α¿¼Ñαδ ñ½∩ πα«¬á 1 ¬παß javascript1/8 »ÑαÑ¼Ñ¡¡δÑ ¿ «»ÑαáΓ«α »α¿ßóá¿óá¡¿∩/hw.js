"use strict";

alert("hello, world!");

let greetings = "Всем привет!";
alert(greetings);