"use strict";

alert("Всем привет!");